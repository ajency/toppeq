---
title: "Add expense"
date: 2020-01-06T12:34:20+05:30
type: "screens"
layout: "add-expense"
---

